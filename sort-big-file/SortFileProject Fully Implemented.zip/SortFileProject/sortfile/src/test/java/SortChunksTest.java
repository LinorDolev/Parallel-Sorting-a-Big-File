import org.junit.Test;
import sortBigFiles.Algorithm;
import sortBigFiles.Record;

import java.util.Comparator;
import java.util.LinkedList;
import java.util.Queue;

public class SortChunksTest {
    @Test
    public void testChunks() {
        final String FILE_PATH = "C:\\Users\\Linor\\Desktop\\linor\\Projects\\SortFile\\data\\Util\\Records.csv";
        final String CHUNKS_PATH = "C:\\Users\\Linor\\Desktop\\linor\\Projects\\SortFile\\data\\Util\\Chunks.csv";

        final int SIZE = 24;
        final int MEM_SIZE = 4;
        final String SORT_KEY = "Country";
        Algorithm algorithm = new Algorithm();
        algorithm.sortBigFile(FILE_PATH, SIZE, MEM_SIZE, SORT_KEY, CHUNKS_PATH);
    }

//    @Test
//    public void testMerge() {
//        int numOfChunks = 5;
//        int chunkSize = 5;
//        String key = "value";
//        Record[][] chunks = new Record[numOfChunks][chunkSize];
//        String value = String.format("%c%d", 'A' + j, i);
//
//        for (int i = 0; i < numOfChunks; i++) {
//            for (int j = 0; j < chunkSize; j++) {
//                chunks[i][j] = new Record(value);
//                chunks[i]put(key, value);
//                System.out.println(value);
//            }
//        }
//
//        Algorithm algorithm = new Algorithm();
//        Record[] results = algorithm.merge(chunks,
//                numOfChunks * chunkSize, Comparator.comparing(r -> r.get(key)));
//
//        System.err.println("===============================");
//        for (Record result: results) {
//            System.out.println(result.get(key));
//        }
//    }
//
//    @Test
//    @SuppressWarnings("unchecked")
//    public void testMergeWithQueues() {
//        int numOfChunks = 5;
//        int chunkSize = 5;
//        int memorySize = numOfChunks * chunkSize;
//        String key = "value";
//        Queue<Record>[] chunks = new Queue[numOfChunks];
//
//        for (int i = 0; i < numOfChunks; i++) {
//            chunks[i] = new LinkedList<>();
//            for (int j = 0; j < chunkSize; j++) {
//                Record record = new Record();
//                String value = String.format("%c%d", 'A' + j, i);
//                record.put(key, value);
//                chunks[i].add(record);
//                System.out.println(value);
//            }
//        }
//
//        Algorithm algorithm = new Algorithm();
//        Queue<Record> results = algorithm.merge(chunks, memorySize, Comparator.comparing(r -> r.get(key)));
//
//        System.err.println("===============================");
//        while (!results.isEmpty()){
//            System.out.println(results.poll().get(key));
//        }
//    }
}
