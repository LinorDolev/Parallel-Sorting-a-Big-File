package sortBigFiles;

import java.util.HashMap;

public class Record{

    private String[] values;

    public Record(String[] values) {
        setValues(values);
    }

    public String get(int index){
        if(index >= values.length)
            throw new IllegalArgumentException(
                    "Illegal index: " + index + ", max possible value: " + (values.length - 1));
        return values[index];
    }

    public String[] getValues() {
        return values;
    }

    private void setValues(String[] values) {
        this.values = values;
    }

    //    public sortBigFiles.Record(String[] keys, String[] values){
//        fromLine(keys, values);
//    }
//
//    private void fromLine(String[] keys, String[] values){
//        for (int i = 0; i < keys.length; i++) {
//            put(keys[i],values[i]);
//        }
//    }
//
//    public String[] toStringArray(String[] keys){
//        String[] values = new String[keys.length];
//        for (int i = 0; i < keys.length; i++) {
//            values[i] = get(keys[i]);
//        }
//        return values;
//    }
}
