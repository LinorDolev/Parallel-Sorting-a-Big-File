package sortBigFiles.fileIOServices;

import java.io.Closeable;
import java.io.IOException;
import java.util.Queue;

import sortBigFiles.Record;

public interface FileWriterService extends Closeable {
    void writeRecords(Queue<Record> records);

    //static void writeRecordsToANewFile(String newFilePath, Record[] records) throws IOException;
}
