package sortBigFiles;

import com.opencsv.exceptions.CsvValidationException;

import java.io.IOException;

public class Main {
    public final static String PATH_FILE = ".\\src\\main\\java\\Util\\Records.csv";

    public static void main(String[] args) throws IOException, CsvValidationException {
       // sortBigFiles.fileIOServices.FileService file = new sortBigFiles.fileIOServices.FileServiceImpl(PATH_FILE);
        //file.readRecords();
    }
}
