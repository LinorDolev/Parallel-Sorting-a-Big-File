package sortBigFiles;

import com.opencsv.exceptions.CsvValidationException;
import sortBigFiles.fileIOServices.FileReaderService;
import sortBigFiles.fileIOServices.FileReaderServiceImpl;
import sortBigFiles.fileIOServices.FileWriterService;
import sortBigFiles.fileIOServices.FileWriterServiceImpl;

import java.io.File;
import java.io.IOException;
import java.util.*;

public class Algorithm {
    private static final String TEMP_FILE_NAME_FORMAT = ".\\SORTED_CHUNK_%d.csv";
//    private static final String TEMP_FILE_SUFFIX = "csv";


    /**
     * sortBigFiles.Main function
     * @param filePath - path to big file to sort
     * @param resultPath - path to write the sorted array to.
     *
     *  Steps:
     *                   1. Read maxMemory sized chunks - once at a time - sort them and write them back to a file
     *                   2. Read maxMemory/numberOfChunks smallest records from each sorted chunk
     *                   3. Merge those records into one buffer (his size is maxMemory)
     *                   4. Write into a new file the maxMemory/numberOfChunks smallest records
     *                   5. Read the next maxMemory/(numberOfChunks)
     *                   6. Go back to 3 until there are no records left in any of the files.
     */
    public void sortBigFile(String filePath, int fileSize, int maxMemory, String sortKey, String resultPath){
        int numberOfChunks = fileSize / maxMemory;
        int queueMaxSize = maxMemory / numberOfChunks;
        int numberOfIterations = (fileSize*numberOfChunks) / maxMemory;
        try(FileReaderService fileReader = new FileReaderServiceImpl(filePath, true);
            FileWriterService resultWriter = new FileWriterServiceImpl(resultPath)){
            int sortKeyIndex = fileReader.indexOfKey(sortKey);
            Comparator<Record> comparator = Comparator.comparing(r -> r.get(sortKeyIndex));
            sortChunks(fileReader, numberOfChunks, maxMemory, comparator);
            FileReaderService[] chunksFileReaders = new FileReaderService[numberOfChunks];
            initChunksReaders(chunksFileReaders);
            List<Queue<Record>> chunkQueues = new ArrayList<>(numberOfChunks);
            initChunksQueues(chunkQueues, numberOfChunks);
            for (int i = 0; i < numberOfIterations; i++) {
                loadSortedRecords(chunksFileReaders, queueMaxSize, chunkQueues);
                Queue<Record> merged = merge(chunkQueues, queueMaxSize, comparator);
                resultWriter.writeRecords(merged);
            }
        } catch (CsvValidationException | IOException e) {
            e.printStackTrace();
        }
    }

    /**
     *
     * @param fileReader - reader of the original big file that we want to sort
     * @param numberOfChunks - number of records in this file / max memory size
     * @param maxMemory - max number of records we are allowed to store in memory
     */
    private void sortChunks(FileReaderService fileReader, int numberOfChunks, int maxMemory, Comparator<Record> comparator) throws IOException, CsvValidationException {
        for (int i = 0; i < numberOfChunks; i++) {
            Record[] records = fileReader.readRecords(maxMemory);
            Arrays.sort(records, comparator);
            FileWriterServiceImpl.writeRecordsToANewFile(String.format(TEMP_FILE_NAME_FORMAT, i), records);
            //TODO file.deleteOnExit();
        }
    }

    private void initChunksQueues(List<Queue<Record>> chunkQueues, int numberOfChunks) {
        for (int i = 0; i < numberOfChunks; i++) {
            chunkQueues.add(new LinkedList<>());
        }
    }

    private void initChunksReaders(FileReaderService[] chunksFileReaders) throws IOException, CsvValidationException {
        for (int i = 0; i < chunksFileReaders.length; i++) {
            chunksFileReaders[i] = new FileReaderServiceImpl(String.format(TEMP_FILE_NAME_FORMAT, i));
        }
    }



    public void loadSortedRecords(FileReaderService[] fileServices, int queueMaxSize, List<Queue<Record>> chunksQueues) throws IOException, CsvValidationException {
        for (int i = 0; i < fileServices.length; i++) {
            FileReaderService chunkFileService = fileServices[i];
            Queue<Record> chunkRecords = chunksQueues.get(i);

            if (chunkRecords.size()< queueMaxSize) {
                Record[] records = chunkFileService.readRecords(queueMaxSize - chunkRecords.size());
                chunkRecords.addAll(Arrays.asList(records));
            }
        }
    }

    public Queue<Record> merge(List<Queue<Record>> chunksQueues, int queueMaxLength, Comparator<Record> comparator){
        Queue<Record> merged = new LinkedList<>();
        while (merged.size() <  queueMaxLength && anyQueueIsNotEmpty(chunksQueues)) {
            int minIndex = 0;
            for (int i = 1; i < chunksQueues.size(); i++) {
                if (comparator.compare(chunksQueues.get(i).peek(), chunksQueues.get(minIndex).peek()) < 0) {
                    minIndex = i;
                }
            }
            merged.add(chunksQueues.get(minIndex).poll());
        }
        return merged;
    }

    private boolean anyQueueIsNotEmpty(List<Queue<Record>> chunks) {
        for (Queue<Record> queue: chunks ) {
            if(!queue.isEmpty()) {
                return true;
            }
        }
        return false;
    }

//    public sortBigFiles.Record[] merge(sortBigFiles.Record[][] chunks, int memorySize, Comparator<sortBigFiles.Record> comparator){
//        int mergeIndex = 0;
//        sortBigFiles.Record[] merged = new sortBigFiles.Record[memorySize];
//        int[] indices = new int[chunks.length];
//
//        while(anyIndicesSmallerThanLength(indices, chunks)) {
//            int minIndex = 0;
//            while(minIndex < chunks.length && indices[minIndex] == FINISHED){
//                minIndex++;
//            }
//            if(minIndex == chunks.length)
//                return merged;
//            for (int i = 0; i < chunks.length; i++) {
//                if (indices[i] != FINISHED &&
//                        comparator.compare(chunks[i][indices[i]], chunks[minIndex][indices[minIndex]]) < 0) {
//                    minIndex = i;
//                }
//            }
//            merged[mergeIndex++] = chunks[minIndex][indices[minIndex]];
//            indices[minIndex]++;
//        }
//        return merged;
//    }
//
//    private boolean anyIndicesSmallerThanLength(int[] indices, sortBigFiles.Record[][] chunks) {
//        boolean result = false;
//        for (int i = 0; i < indices.length; i++) {
//            if(indices[i] < chunks[i].length){
//                result = true;
//            }
//            else{
//                indices[i] = FINISHED;
//            }
//        }
//        return result;
//    }
}
