package sortBigFiles.fileIOServices;

import com.opencsv.exceptions.CsvValidationException;

import java.io.Closeable;
import java.io.IOException;

import sortBigFiles.Record;

public interface FileReaderService extends Closeable {
    Record[] readRecords(int amount) throws IOException, CsvValidationException;

    int indexOfKey(String key);

    String[] getKeys();

}
