import org.junit.Test;
import sortBigFile.ParallelAlgorithms;

import java.util.Arrays;

public class TestParallel {
    @Test
    public void testParallelSort() throws InterruptedException {
        final int SIZE = 1000;
        Integer[] numbers = new Integer[SIZE];
        for (int i = 0; i < numbers.length; i++) {
            numbers[i] = (int) (Math.random() * SIZE * SIZE);
        }
        Integer[] expected = Arrays.copyOf(numbers, numbers.length);
        ParallelAlgorithms.parallelMergeSort(numbers, Integer::compare);
        System.out.println(Arrays.toString(numbers));
        Arrays.sort(expected);
        System.out.println("\n=================================================\n");
        System.out.println(Arrays.toString(expected));
        assert Arrays.equals(numbers, expected);
    }
}
