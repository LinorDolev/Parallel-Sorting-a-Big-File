import com.opencsv.exceptions.CsvValidationException;
import org.junit.Test;
import sortBigFile.Algorithm;
import sortBigFile.fileIOServices.FileReaderService;
import sortBigFile.fileIOServices.FileReaderServiceImpl;

import java.io.IOException;
import java.util.Date;

public class SortChunksTest {
    @Test
    public void testChunks() {
        final String FILE_PATH = ".\\data\\24 Records.csv";
        final String CHUNKS_PATH = String.format(".\\data\\SortedRecords%d.csv", new Date().getTime());

        final int SIZE = 24;
        final int MEM_SIZE = 6;
        final String SORT_KEY = "Region";
        Algorithm algorithm = new Algorithm();
        algorithm.sortBigFile(FILE_PATH, SIZE, MEM_SIZE, SORT_KEY, CHUNKS_PATH);
    }

    @Test
    public void testMemorySizeNotDivisibleByNumOfChunks() {
        final String FILE_PATH = ".\\data\\10000 Records.csv";
        final String CHUNKS_PATH = String.format(".\\data\\SortedRecords%d.csv", new Date().getTime());

        final int SIZE = 10000;
        final int MEM_SIZE = 101;
        final String SORT_KEY = "First Name";
        Algorithm algorithm = new Algorithm();
        algorithm.sortBigFile(FILE_PATH, SIZE, MEM_SIZE, SORT_KEY, CHUNKS_PATH);
    }

    @Test
    public void testMemoryBiggerThanFile() {
        final String FILE_PATH = ".\\data\\10000 Records.csv";
        final String CHUNKS_PATH = String.format(".\\data\\SortedRecords%d.csv", new Date().getTime());

        final int SIZE = 10000;
        final int MEM_SIZE = 100000;
        final String SORT_KEY = "First Name";
        Algorithm algorithm = new Algorithm();
        algorithm.sortBigFile(FILE_PATH, SIZE, MEM_SIZE, SORT_KEY, CHUNKS_PATH);
    }

    /**
     *  This causing: memory < numOfChunks
     *  Not Working!
     *  TODO Handle this case using partition merging
     */
    @Test
    public void testMemoryIsSmallerThanSqrtOfFileSize() {
        final String FILE_PATH = ".\\data\\10000 Records.csv";
        final String CHUNKS_PATH = String.format(".\\data\\SortedRecords%d.csv", new Date().getTime());

        final int SIZE = 10000;
        final int MEM_SIZE = 10;
        final String SORT_KEY = "First Name";
        Algorithm algorithm = new Algorithm();
        algorithm.sortBigFile(FILE_PATH, SIZE, MEM_SIZE, SORT_KEY, CHUNKS_PATH);
    }
}
